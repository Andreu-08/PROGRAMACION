package Practica_Banc_Exepcions.deparbankv2.Exception;
    public class AvisarHisendaException extends Exception {
        public AvisarHisendaException(String message) {
            super(message);
        }
    }


