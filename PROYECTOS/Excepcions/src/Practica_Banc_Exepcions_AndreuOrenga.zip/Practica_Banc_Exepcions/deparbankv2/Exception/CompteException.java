package Practica_Banc_Exepcions.deparbankv2.Exception;
    public class CompteException extends Exception {
        public CompteException(String message) {
            super(message);
        }
    }


