package Exercici_Joc;

public interface IJugable {
    void jugar();
    void mostrarNom();
    void mostrarInfo();
}
